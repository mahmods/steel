<?php

/**
 * Main front-end controller for Types.
 * 
 * @since 2.0
 */
final class Types_Frontend {

	public static function initialize() {

	}

}